<?php
/**
 * Silence is golden.
 *
 * @package AI_Story_Maker
 */
