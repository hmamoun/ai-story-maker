// create a function to make a fetch request to the server
// the function should not start if another request is already in progress (use a flag)
// the function should send the nonce to the server
// the function should handle the response from the server
// the function should handle errors and write in the log
